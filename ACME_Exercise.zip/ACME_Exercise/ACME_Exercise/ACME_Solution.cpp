#include <cstdio>
#include <iostream>
#include <string>

using namespace std;

constexpr int maxstring = 1024;    // read buffer size

int i = 0;
char name[10] = " ";
int payment = 0;

char buf[maxstring];
bool flag = true;

void GetName()
{
	while (buf[i] != '=')				//while loop to save the name of the worker in
	{
		name[i] = buf[i];
		i++;
	}
	i++;
}

int GetPaymentPerDay()				//FUNCTION TO GET THE PAYMENT PER DAY
{
	int j = 0;
	char cday[] = "Mo";
	string day;
	char workday[13];
	char DhourS[1];
	char UhourS[1];
	int  DIhourS;
	int  UIhourS;
	int  WorkHourS;
	char DhourE[1];
	char UhourE[1];
	int  DIhourE;
	int  UIhourE;
	int  WorkHourE;
	int  HoursWorked;
	int DayPayment;
	while (buf[i] != ',' && buf[i] != '.')	//WHILE TO SAVE INFO IN AN ARRAY
	{
		workday[j] = buf[i];
		i++;
		j++;
	}

	cday[0] = workday[0];					//SAVING THE WORKDAY IN AN ARRAY
	cday[1] = workday[1];
	day = cday;								//SAVING THE ARRAY AS STRING
	///////////////////////					GETTING THE WORK START HOUR
	DhourS[0] = workday[2];
	UhourS[0]  = workday[3];
	DIhourS = atoi(DhourS);
	UIhourS = atoi(UhourS);
	WorkHourS = (DIhourS * 10) + UIhourS;
	///////////////////////					GETTING THE WORK END HOUR
	DhourE[0] = workday[8];
	UhourE[0] = workday[9];
	DIhourE = atoi(DhourE);
	UIhourE = atoi(UhourE);
	WorkHourE = (DIhourE * 10) + UIhourE;
	///////////////////////
	
	// CHECKS FOR THE DAY OF THE WEEK THE PERSON WORKED AND CALCULATES THE PAYMENT
	if (day == "MO" || day == "TU" || day == "WE" || day == "TH" || day == "FR")						//CHECKING WHICH DAY IS IT
	{
		if (WorkHourS >= 0 && WorkHourS <= 9)
		{
			
			if (WorkHourE >= 00 && WorkHourE <= 9)
			{
				HoursWorked = WorkHourE - WorkHourS;
				DayPayment = HoursWorked * 25;
			}
			else
			{
				DayPayment = ((9 - WorkHourS) * 25) + ((WorkHourE - 9)*15);
			}

		}
		else if (WorkHourS >= 9 && WorkHourS <= 18 )
		{
			if (WorkHourE >= 9 && WorkHourE <= 18)
			{
				HoursWorked = WorkHourE - WorkHourS;
				DayPayment = HoursWorked * 15;
			}
			else
			{
				DayPayment = ((18 - WorkHourS) * 15) + ((WorkHourE - 18) * 20);
			}
		}
		else if (WorkHourS >= 18 && WorkHourS >= 0)
		{
			if (WorkHourE >= 18 && WorkHourE >= 0)
			{
				HoursWorked = WorkHourE - WorkHourS;
				DayPayment = HoursWorked * 20;
			}
			else
			{
				DayPayment = ((24 - WorkHourS) * 20) + ((WorkHourE) * 25);
			}
		}


	}
	else if (day == "SA" || day == "SU")
	{
		if (WorkHourS >= 0 && WorkHourS <= 9)
		{
			if (WorkHourE >= 00 && WorkHourE <= 9)
			{
				HoursWorked = WorkHourE - WorkHourS;
				DayPayment = HoursWorked * 30;
			}
			else
			{
				DayPayment = ((9 - WorkHourS) * 30) + ((WorkHourE - 9) * 20);
			}

		}
		else if (WorkHourS >= 9 && WorkHourS <= 18)
		{
			if (WorkHourE >= 9 && WorkHourE <= 18)
			{
				HoursWorked = WorkHourE - WorkHourS;
				DayPayment = HoursWorked * 20;
			}
			else
			{
				DayPayment = ((18 - WorkHourS) * 20) + ((WorkHourE - 18) * 25);
			}
		}
		else if (WorkHourS >= 18 && WorkHourS >= 0)
		{
			if (WorkHourE >= 18 && WorkHourE >= 0)
			{
				HoursWorked = WorkHourE - WorkHourS;
				DayPayment = HoursWorked * 25;
			}
			else
			{
				DayPayment = ((24 - WorkHourS) * 25) + ((WorkHourE) * 30);
			}
		}
	}
	//////////////////////////////////////////
	if (buf[i] == '.')
		flag = false;
	return DayPayment;
}

int main(int argc, char ** argv) {
	const char * fn = "ACME.txt";   // file name
	
	// read the file
	printf("reading file\n");
	FILE * fr = fopen(fn, "r");
	while (fgets(buf, maxstring, fr)) {		//while loop to read each line
		GetName();
		while (flag)
		{
			payment = payment + GetPaymentPerDay();
			i++;
		}
		printf("\nThe amount to pay %s is: %d USD\n", name, payment);

		i = 0;
		flag = true;
		payment = 0;
	}

	fclose(fr);

	return 0;
}
